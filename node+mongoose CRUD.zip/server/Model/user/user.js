const mongoose = require('mongoose');
const timestamps = require('mongoose-timestamp');
// const ObjectId = require('mongoose').mongoose.Schema.Types;

const userSchema = new mongoose.Schema({
	username: {
		type: String,
		trim: true,
		required: true,
	},
	password: {
		type: String,
		trim: true,
		required: true,
	},
	mobile_number: {
		type: String,
		trim: true
	},
	email: {
		type: String,
		trim: true
	},
	dob: {
		type: String,
		trim: true,
		required: true,
	}
}, { collection: 'user' });

userSchema.plugin(timestamps)

module.exports = exports = mongoose.model('user', userSchema)