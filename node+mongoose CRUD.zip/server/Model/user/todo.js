
const mongoose = require('mongoose');
const timestamps = require('mongoose-timestamp');
const ObjectId = mongoose.Schema.Types;

const TodoSchema = new mongoose.Schema({
	user_id: {
		type: ObjectId,
		trim: true,
		required: true,
	},
	title: {
		type: String,
		trim: true,
		required: true,
	},
	date: {
		type:String,
		trim: true,
		required: true,
	},
	description: {
		type:String,
		trim: true,
		required: true,
	},
}, { collection: 'todolist' });

TodoSchema.plugin(timestamps)

module.exports = exports = mongoose.model('todo', TodoSchema)