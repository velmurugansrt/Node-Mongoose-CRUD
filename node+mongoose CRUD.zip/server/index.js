'use strict';
var express = require('express');
var router = express.Router()
var user = require('./Controller/user');
var cors = require('cors');
var app = express();
const mongoose = require('mongoose');
var utils = require('./utils/config.js');


   
mongoose.connect(utils.setmydb());
mongoose.connection.on('connected', function () {
    console.log("Mongoose default connection is open to ", utils.setmydb());
});
mongoose.connection.on('disconnected', function(){
    console.log("Mongoose default connection is disconnected");
});

app.use(function (req, res, next) {
 
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});
router.use('/user', user);

module.exports = router