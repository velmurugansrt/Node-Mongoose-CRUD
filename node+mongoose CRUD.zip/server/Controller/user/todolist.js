'use strict';
var MongoClient = require('mongodb').MongoClient;
var empty = require('is-empty');
var trim = require('trim');
var utils = require('./../../utils/config.js');
var Validator = require('validatorjs');
var todoschema = require('../../Model/user/todo.js');
var async = require('async');
var todolist = {
	//Mobile registration function
	request: function (req, res) {
		try {
			var data = {
				"user_id": req.body.user_id,
			};

			var rules = {
				user_id: 'required'
			};

			var validation = new Validator(data, rules);
			if (validation.passes() === false) {
				var result = { "response_code": "1", "message": "enter valid data", "result": {} };
				res.json(result);
			} else {
				var data = {
					"user_id": req.body.user_id
				}
				todoschema.find(data, 'name user_id title date description', function (err, result) {
					if (err) throw err;
					var responsedata = { "response_code": "0", "message": "Added successfully", "result": result };
					res.json(responsedata);
				});
			}
		} catch (e) {
			console.log(e);
		}
	}
}
module.exports = todolist;